using System;
using System.Collections.Generic;
using System.Linq;
using Newtonsoft.Json;
using TaskManager.Models;

namespace TaskManager.Services
{
    public class TaskService
    {
        private List<StudentTask> _tasks;
        private readonly string _filePath = "tasks.json";
        private int _nextId = 1;

        public TaskService()
        {
            _tasks = LoadTasks();
            if (_tasks.Any())
            {
                _nextId = _tasks.Max(t => t.Id) + 1;
            }
        }

        public List<StudentTask> GetAllTasks()
        {
            return _tasks;
        }

        public List<StudentTask> GetTasksByCategory(string category)
        {
            return _tasks.Where(t => t.Category == category).ToList();
        }

        public List<StudentTask> GetTasksByPriority(TaskPriority priority)
        {
            return _tasks.Where(t => t.Priority == priority).ToList();
        }

        public List<StudentTask> GetTasksByDeadline(DateTime date)
        {
            return _tasks.Where(t => t.Deadline.Date == date.Date).ToList();
        }

        public void AddTask(StudentTask task)
        {
            task.Id = _nextId++;
            _tasks.Add(task);
            SaveTasks();
        }

        public void UpdateTask(StudentTask task)
        {
            var existingTask = _tasks.FirstOrDefault(t => t.Id == task.Id);
            if (existingTask != null)
            {
                var index = _tasks.IndexOf(existingTask);
                _tasks[index] = task;
                SaveTasks();
            }
        }

        public void DeleteTask(int taskId)
        {
            _tasks.RemoveAll(t => t.Id == taskId);
            SaveTasks();
        }

        public List<StudentTask> GetDueReminders()
        {
            return _tasks.Where(t => 
                !t.IsCompleted && 
                t.ReminderTime.HasValue && 
                t.ReminderTime.Value <= DateTime.Now
            ).ToList();
        }

        private List<StudentTask> LoadTasks()
        {
            try
            {
                if (File.Exists(_filePath))
                {
                    var json = File.ReadAllText(_filePath);
                    return JsonConvert.DeserializeObject<List<StudentTask>>(json) ?? new List<StudentTask>();
                }
            }
            catch (Exception ex)
            {
                // В реальном приложении здесь должно быть логирование
                Console.WriteLine($"Error loading tasks: {ex.Message}");
            }
            return new List<StudentTask>();
        }

        private void SaveTasks()
        {
            try
            {
                var json = JsonConvert.SerializeObject(_tasks, Formatting.Indented);
                File.WriteAllText(_filePath, json);
            }
            catch (Exception ex)
            {
                // В реальном приложении здесь должно быть логирование
                Console.WriteLine($"Error saving tasks: {ex.Message}");
            }
        }
    }
} 