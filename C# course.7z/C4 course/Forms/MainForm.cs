using System;
using System.Drawing;
using System.Windows.Forms;
using TaskManager.Models;
using TaskManager.Services;

namespace TaskManager.Forms
{
    public partial class MainForm : Form
    {
        private readonly TaskService _taskService;
        private System.Windows.Forms.Timer _reminderTimer;

        private ListView taskListView;
        private TextBox titleTextBox;
        private TextBox descriptionTextBox;
        private DateTimePicker deadlinePicker;
        private ComboBox priorityComboBox;
        private TextBox categoryTextBox;
        private CheckBox reminderCheckBox;
        private DateTimePicker reminderTimePicker;
        private Button addButton;
        private Button editButton;
        private Button deleteButton;

        // Цвета для темной темы
        private readonly Color darkBackground = Color.FromArgb(32, 32, 32);
        private readonly Color darkForeground = Color.White;
        private readonly Color darkControlBackground = Color.FromArgb(48, 48, 48);
        private readonly Color darkControlBorder = Color.FromArgb(64, 64, 64);
        private readonly Color darkButtonBackground = Color.FromArgb(64, 64, 64);
        private readonly Color darkButtonHover = Color.FromArgb(80, 80, 80);
        private readonly Color darkListViewBackground = Color.FromArgb(40, 40, 40);
        private readonly Color darkListViewForeground = Color.White;
        private readonly Color darkListViewSelected = Color.FromArgb(0, 120, 215);

        public MainForm()
        {
            InitializeComponent();
            _taskService = new TaskService();
            InitializeTimer();
            LoadTasks();
            ApplyDarkTheme();
        }

        private void ApplyDarkTheme()
        {
            // Настройка цветов формы
            this.BackColor = darkBackground;
            this.ForeColor = darkForeground;

            // Настройка ListView
            taskListView.BackColor = darkListViewBackground;
            taskListView.ForeColor = darkListViewForeground;
            taskListView.BorderStyle = BorderStyle.FixedSingle;
            taskListView.OwnerDraw = true;
            taskListView.DrawColumnHeader += (s, e) =>
            {
                e.Graphics.FillRectangle(new SolidBrush(darkControlBackground), e.Bounds);
                TextRenderer.DrawText(e.Graphics, taskListView.Columns[e.ColumnIndex].Text,
                    e.Font, e.Bounds, darkForeground, TextFormatFlags.VerticalCenter | TextFormatFlags.Left);
            };
            taskListView.DrawItem += (s, e) =>
            {
                e.DrawDefault = true;
            };
            taskListView.DrawSubItem += (s, e) =>
            {
                e.DrawDefault = true;
            };

            // Настройка текстовых полей
            void SetupTextBox(TextBox textBox)
            {
                textBox.BackColor = darkControlBackground;
                textBox.ForeColor = darkForeground;
                textBox.BorderStyle = BorderStyle.FixedSingle;
            }

            SetupTextBox(titleTextBox);
            SetupTextBox(descriptionTextBox);
            SetupTextBox(categoryTextBox);

            // Настройка DateTimePicker
            void SetupDateTimePicker(DateTimePicker picker)
            {
                picker.CalendarMonthBackground = darkControlBackground;
                picker.CalendarTitleBackColor = darkControlBackground;
                picker.CalendarTitleForeColor = darkForeground;
                picker.CalendarForeColor = darkForeground;
                picker.BackColor = darkControlBackground;
                picker.ForeColor = darkForeground;
            }

            SetupDateTimePicker(deadlinePicker);
            SetupDateTimePicker(reminderTimePicker);

            // Настройка ComboBox
            priorityComboBox.BackColor = darkControlBackground;
            priorityComboBox.ForeColor = darkForeground;
            priorityComboBox.FlatStyle = FlatStyle.Flat;

            // Настройка CheckBox
            reminderCheckBox.BackColor = darkBackground;
            reminderCheckBox.ForeColor = darkForeground;

            // Настройка кнопок
            void SetupButton(Button button)
            {
                button.FlatStyle = FlatStyle.Flat;
                button.BackColor = darkButtonBackground;
                button.ForeColor = darkForeground;
                button.FlatAppearance.BorderColor = darkControlBorder;
                button.FlatAppearance.MouseOverBackColor = darkButtonHover;
            }

            SetupButton(addButton);
            SetupButton(editButton);
            SetupButton(deleteButton);
        }

        private void InitializeComponent()
        {
            // Настройка формы
            this.Text = "Student Task Manager";
            this.Size = new Size(900, 600);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.MinimumSize = new Size(800, 500);

            // Создание и настройка ListView
            taskListView = new ListView();
            taskListView.Location = new Point(10, 10);
            taskListView.Size = new Size(400, 500);
            taskListView.View = View.Details;
            taskListView.FullRowSelect = true;
            taskListView.GridLines = true;
            taskListView.Columns.Add("Title", 150);
            taskListView.Columns.Add("Deadline", 100);
            taskListView.Columns.Add("Priority", 70);
            taskListView.Columns.Add("Category", 80);

            // Создание панели для правой части
            var rightPanel = new Panel();
            rightPanel.Location = new Point(420, 10);
            rightPanel.Size = new Size(450, 500);

            // Создание и настройка элементов управления
            var titleLabel = new Label { Text = "Title:", Location = new Point(10, 10), AutoSize = true };
            titleTextBox = new TextBox { Location = new Point(10, 30), Size = new Size(200, 20) };

            var descriptionLabel = new Label { Text = "Description:", Location = new Point(10, 60), AutoSize = true };
            descriptionTextBox = new TextBox { Location = new Point(10, 80), Size = new Size(200, 60), Multiline = true };

            var deadlineLabel = new Label { Text = "Deadline:", Location = new Point(10, 150), AutoSize = true };
            deadlinePicker = new DateTimePicker { Location = new Point(10, 170), Size = new Size(200, 20) };

            var priorityLabel = new Label { Text = "Priority:", Location = new Point(10, 200), AutoSize = true };
            priorityComboBox = new ComboBox { Location = new Point(10, 220), Size = new Size(200, 20) };

            var categoryLabel = new Label { Text = "Category:", Location = new Point(10, 250), AutoSize = true };
            categoryTextBox = new TextBox { Location = new Point(10, 270), Size = new Size(200, 20) };

            reminderCheckBox = new CheckBox { Text = "Set Reminder", Location = new Point(10, 300), AutoSize = true };
            reminderTimePicker = new DateTimePicker { Location = new Point(10, 330), Size = new Size(200, 20), Enabled = false };

            // Создание и настройка кнопок
            addButton = new Button { Text = "Add Task", Location = new Point(10, 370), Size = new Size(100, 30) };
            editButton = new Button { Text = "Edit Task", Location = new Point(120, 370), Size = new Size(100, 30) };
            deleteButton = new Button { Text = "Delete Task", Location = new Point(230, 370), Size = new Size(100, 30) };

            // Добавление обработчиков событий
            addButton.Click += AddButton_Click;
            editButton.Click += EditButton_Click;
            deleteButton.Click += DeleteButton_Click;
            reminderCheckBox.CheckedChanged += (s, e) => reminderTimePicker.Enabled = reminderCheckBox.Checked;
            taskListView.SelectedIndexChanged += TaskListView_SelectedIndexChanged;

            // Добавление элементов на правую панель
            rightPanel.Controls.AddRange(new Control[] {
                titleLabel, titleTextBox,
                descriptionLabel, descriptionTextBox,
                deadlineLabel, deadlinePicker,
                priorityLabel, priorityComboBox,
                categoryLabel, categoryTextBox,
                reminderCheckBox, reminderTimePicker,
                addButton, editButton, deleteButton
            });

            // Добавление элементов на форму
            this.Controls.Add(taskListView);
            this.Controls.Add(rightPanel);

            // Инициализация компонентов
            priorityComboBox.DataSource = Enum.GetValues(typeof(TaskPriority));
        }

        private void InitializeTimer()
        {
            _reminderTimer = new System.Windows.Forms.Timer();
            _reminderTimer.Interval = 60000; // Проверка каждую минуту
            _reminderTimer.Tick += ReminderTimer_Tick;
            _reminderTimer.Start();
        }

        private void LoadTasks()
        {
            taskListView.Items.Clear();
            var tasks = _taskService.GetAllTasks();
            foreach (var task in tasks)
            {
                AddTaskToListView(task);
            }
        }

        private void AddTaskToListView(StudentTask task)
        {
            var item = new ListViewItem(task.Title);
            item.SubItems.Add(task.Deadline.ToString("g"));
            item.SubItems.Add(task.Priority.ToString());
            item.SubItems.Add(task.Category);
            item.Tag = task;
            taskListView.Items.Add(item);
        }

        private void AddButton_Click(object sender, EventArgs e)
        {
            var task = new StudentTask
            {
                Title = titleTextBox.Text,
                Description = descriptionTextBox.Text,
                Deadline = deadlinePicker.Value,
                Priority = (TaskPriority)priorityComboBox.SelectedItem,
                Category = categoryTextBox.Text,
                ReminderTime = reminderCheckBox.Checked ? reminderTimePicker.Value : null
            };

            _taskService.AddTask(task);
            LoadTasks();
            ClearInputs();
        }

        private void EditButton_Click(object sender, EventArgs e)
        {
            if (taskListView.SelectedItems.Count == 0) return;

            var task = (StudentTask)taskListView.SelectedItems[0].Tag;
            task.Title = titleTextBox.Text;
            task.Description = descriptionTextBox.Text;
            task.Deadline = deadlinePicker.Value;
            task.Priority = (TaskPriority)priorityComboBox.SelectedItem;
            task.Category = categoryTextBox.Text;
            task.ReminderTime = reminderCheckBox.Checked ? reminderTimePicker.Value : null;

            _taskService.UpdateTask(task);
            LoadTasks();
            ClearInputs();
        }

        private void DeleteButton_Click(object sender, EventArgs e)
        {
            if (taskListView.SelectedItems.Count == 0) return;

            var task = (StudentTask)taskListView.SelectedItems[0].Tag;
            _taskService.DeleteTask(task.Id);
            LoadTasks();
            ClearInputs();
        }

        private void TaskListView_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (taskListView.SelectedItems.Count == 0) return;

            var task = (StudentTask)taskListView.SelectedItems[0].Tag;
            titleTextBox.Text = task.Title;
            descriptionTextBox.Text = task.Description;
            deadlinePicker.Value = task.Deadline;
            priorityComboBox.SelectedItem = task.Priority;
            categoryTextBox.Text = task.Category;
            reminderCheckBox.Checked = task.ReminderTime.HasValue;
            if (task.ReminderTime.HasValue)
            {
                reminderTimePicker.Value = task.ReminderTime.Value;
            }
        }

        private void ReminderTimer_Tick(object sender, EventArgs e)
        {
            var dueReminders = _taskService.GetDueReminders();
            foreach (var task in dueReminders)
            {
                ShowReminderNotification(task);
            }
        }

        private void ShowReminderNotification(StudentTask task)
        {
            var notification = new NotifyIcon();
            notification.Icon = SystemIcons.Information;
            notification.BalloonTipTitle = "Task Reminder";
            notification.BalloonTipText = $"Task '{task.Title}' is due {task.Deadline:g}";
            notification.Visible = true;
            notification.ShowBalloonTip(5000);
        }

        private void ClearInputs()
        {
            titleTextBox.Clear();
            descriptionTextBox.Clear();
            deadlinePicker.Value = DateTime.Now;
            priorityComboBox.SelectedIndex = 0;
            categoryTextBox.Clear();
            reminderCheckBox.Checked = false;
            reminderTimePicker.Value = DateTime.Now;
        }
    }
} 